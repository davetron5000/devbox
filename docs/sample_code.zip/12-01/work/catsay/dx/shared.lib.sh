log() {
  echo "[ ${0} ]" "${@}"
} # log

if [ -z $SCRIPT_DIR ]; then
  log "SCRIPT_DIR was not defined"
  exit 1
fi
# START:edit:3

check_for_docker() {
  if ! command -v "docker" > /dev/null 2>&1; then
    log "Docker is not installed."
    log "Please visit https://docs.docker.com/get-docker/"
    exit 1
  fi
  log "Docker is installed!"
}

# END:edit:3

ROOT_DIR=$(cd -- "${SCRIPT_DIR}"/.. > /dev/null 2>&1 && pwd)
